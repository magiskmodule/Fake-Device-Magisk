#!/bin/sh
MODDIR=${0%/*}

$MODDIR/FINIXOS