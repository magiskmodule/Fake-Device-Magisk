SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE="
"



print_modname() {
ui_print "- Tʜᴀɴᴋs Tᴏ                           
 _______  _         _        
(_______)(_)       (_)       
 _____    _  ____   _  _   _ 
|  ___)  | ||  _ \ | |( \ / )
| |      | || | | || | ) X ( 
|_|      |_||_| |_||_|(_/ \_)
                             "
ui_print ""  
ui_print "> Fake Device  "
sleep 1
ui_print "> Rasakan Sensasi Baru !!!"
sleep 1
ui_print "> Gak Bootloop Gak Ganteng 🗿"
sleep 2
ui_print "> Ready...    "
}


on_install() {
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'FINIXOS' -d $MODPATH >&2
}


set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0777 0777
}

